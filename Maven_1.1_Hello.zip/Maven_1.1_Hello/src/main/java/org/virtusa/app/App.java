package org.virtusa.app;

/**
 * Hello Maven!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello Maven!" );
    }
}
